How to use CART_TUB in MAPLE:

1. Copy the content of the folder inside the working directory

2. Load the TUBULAR package and then a relevant (in terms of tubular type) CART_TUB package

3. Prepare the environments for the package by calling following command(s): 

	> conf_var(); # for the tubular type (2,2,2,2)
	> read_sheaf();read_cart();read_tiltList();calc_cart_class() # for the tubular types (3,3,3), (2,4,4) and (3,4,6)
	
   This might take several minutes depending on the tubular type and hardware performance.
   
4. Ready to use


The demo244.mw shows how to switch between (infinity)/(1) normalizations and how to check if a given matrix is a Cartan matrix (up to renumeration relation) of some tubular algebra (+ the list of some tilting realizations).


Note, that the presented package was written using CAS MAPLE ver. 9.5 and might not be compatible with other versions of the software.